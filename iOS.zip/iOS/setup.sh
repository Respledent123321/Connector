#!/bin/bash
echo "Setting up dependencies..."
pip install -r requirements.txt
echo "Starting application..."
python3 app.py