import subprocess
import sys
import os
import time
import threading
import socket
import json

def install(package):
    print(f"Installing {package}...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", package])

# Auto-install dependencies logic
try:
    from flask import Flask, render_template, request, jsonify
    from cryptography.fernet import Fernet
except ImportError:
    print("Dependencies missing. Installing...")
    try:
        install("flask")
        install("cryptography")
        print("Dependencies installed. Restarting application...")
        os.execv(sys.executable, [sys.executable] + sys.argv)
    except Exception as e:
        print(f"Failed to auto-install: {e}")
        print("Please run 'pip install flask cryptography' manually.")
        sys.exit(1)

app = Flask(__name__)

# Configuration
TARGET_HOST = "100.120.98.109"  # Windows IP
TARGET_PORT = 5555
SECRET_KEY = b'pJjmfm32J7g2Xut6x7hhHN3Fd3PJfDADL7GuYJygYuM=' 
cipher_suite = Fernet(SECRET_KEY)

# Global State
messages = []
client_socket = None
connected = False

def connect_to_server():
    global client_socket, connected
    while True:
        try:
            if not connected:
                print(f"Attempting connection to {TARGET_HOST}:{TARGET_PORT}...")
                client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                client_socket.settimeout(5) # 5s timeout for connection
                client_socket.connect((TARGET_HOST, TARGET_PORT))
                client_socket.settimeout(None) # Reset timeout
                connected = True
                print("Connected to Server!")
                
                # Listen loop
                while connected:
                    try:
                        data = client_socket.recv(1024)
                        if not data:
                            print("Server closed connection.")
                            break
                        try:
                            decrypted_msg = cipher_suite.decrypt(data).decode()
                            # Avoid duplicates if possible, but simple append is safer for now
                            messages.append({"sender": "Windows", "text": decrypted_msg})
                        except Exception as e:
                            print(f"Decryption error: {e}")
                    except ConnectionResetError:
                        print("Connection reset.")
                        break
                    except Exception as e:
                        print(f"Socket error: {e}")
                        break
                
                connected = False
                if client_socket:
                    client_socket.close()
                client_socket = None
                print("Disconnected. Retrying in 5s...")
                time.sleep(5)
            else:
                time.sleep(1) 
        except Exception as e:
            print(f"Connection failed: {e}")
            connected = False
            time.sleep(5)

# Start background thread
threading.Thread(target=connect_to_server, daemon=True).start()

@app.route('/')
def index():
    return render_template('splash.html')

@app.route('/chat')
def chat():
    return render_template('index.html')

@app.route('/send', methods=['POST'])
def send_msg():
    data = request.json
    msg = data.get('message')
    if msg:
        if connected and client_socket:
            try:
                encrypted_msg = cipher_suite.encrypt(msg.encode())
                client_socket.send(encrypted_msg)
                messages.append({"sender": "Me", "text": msg})
                return jsonify({"status": "sent"})
            except Exception as e:
                return jsonify({"status": "error", "message": str(e)})
        else:
            return jsonify({"status": "error", "message": "Not connected"})
    return jsonify({"status": "error", "message": "Empty message"})

@app.route('/get_messages')
def get_messages():
    return jsonify(messages)

if __name__ == '__main__':
    # Run on 0.0.0.0 so it is accessible
    print("Starting Web Interface on port 5000...")
    app.run(host='0.0.0.0', port=5000, debug=False)